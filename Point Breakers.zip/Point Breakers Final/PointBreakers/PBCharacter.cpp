// Fill out your copyright notice in the Description page of Project Settings.


#include "PointBreakers/PBCharacter.h"
#include "PointBreakers/PBPlayerState.h"
#include "PointBreakers/PBGameState.h"
#include "PointBreakers/Grenade.h"
#include "Components/InputComponent.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"

// Sets default values
APBCharacter::APBCharacter()
{
    // Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;

    // Create the Spring Arm, attach it to the Root component, and rotate it with control rotation
    SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("Spring Arm"));
    SpringArm->SetupAttachment(GetRootComponent());
    SpringArm->bUsePawnControlRotation = true;

    // Create the Camera and attach it to the Spring Arm
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
    Camera->SetupAttachment(SpringArm);
}

// Called when the game starts or when spawned
void APBCharacter::BeginPlay()
{
    Super::BeginPlay();

    // Get the associated PlayerController
    if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
    {
        // Get the Enhanced Input Local Player Subsystem from the PlayerController (and the LocalPlayer)
        if (UEnhancedInputLocalPlayerSubsystem* EILPSubsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
        {
            // Use the subsystem to add the mapping context
            EILPSubsystem->AddMappingContext(CharacterContext, 0);
        }
    }
}

// Called every frame
void APBCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void APBCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    // Take our PlayerInputComponent (of type UInputComponent) and cast it to a UEnhancedInputComponent
    // This lets us tap into the features of the new Enhanced Input system (vs. the old input system)
    // CastChecked is like Cast, but will crash on failure
    if (UEnhancedInputComponent* EnhancedInputComponent = CastChecked<UEnhancedInputComponent>(PlayerInputComponent))
    {
        // Bind Input Actions to Callback Functions
        EnhancedInputComponent->BindAction(MoveAction, ETriggerEvent::Triggered, this, &APBCharacter::MoveCallback);
        EnhancedInputComponent->BindAction(LookAction, ETriggerEvent::Triggered, this, &APBCharacter::LookCallback);
        EnhancedInputComponent->BindAction(JumpAction, ETriggerEvent::Triggered, this, &APBCharacter::JumpCallback);
        EnhancedInputComponent->BindAction(ShootAction, ETriggerEvent::Triggered, this, &APBCharacter::ShootCallback);
    }
}

void APBCharacter::MoveCallback(const FInputActionValue& Value)
{
    APBGameState* PBGameState = Cast<APBGameState>(UGameplayStatics::GetGameState(GetWorld()));
    if (PBGameState && !PBGameState->Win && !PBGameState->Lose) {
        FVector2D MoveInput = Value.Get<FVector2D>();

        // Get the Forward and Right axes of the ControlRotation
        FVector ForwardDirection = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::X);
        FVector RightDirection = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::Y);

        // Add movement 
        AddMovementInput(ForwardDirection, MoveInput.Y);
        AddMovementInput(RightDirection, MoveInput.X);
    }
}

void APBCharacter::LookCallback(const FInputActionValue& Value)
{
    APBGameState* PBGameState = Cast<APBGameState>(UGameplayStatics::GetGameState(GetWorld()));
    if (PBGameState && !PBGameState->Win && !PBGameState->Lose) {
        FVector2D LookInput = Value.Get<FVector2D>();

        // LookUp
        AddControllerPitchInput(LookInput.Y);

        // LookRight
        AddControllerYawInput(LookInput.X);
    }
}

void APBCharacter::JumpCallback(const FInputActionValue& Value)
{
    // Call ACharacter::Jump()
    APBGameState* PBGameState = Cast<APBGameState>(UGameplayStatics::GetGameState(GetWorld()));
    if (!PBGameState->Win && !PBGameState->Lose) {
        Jump();
    }

}

void APBCharacter::ShootCallback(const FInputActionValue& Value)
{
    APBGameState* PBGameState = Cast<APBGameState>(UGameplayStatics::GetGameState(GetWorld()));
    APBPlayerState* PBPlayerState = Cast<APBPlayerState>(GetPlayerState());
    if (PBPlayerState->CurrentAmmo != 0 || (!PBGameState->Win && !PBGameState->Lose)) {

        AGrenade* SpawnedGrenade = GetWorld()->SpawnActor<AGrenade>(AGrenade::StaticClass(), FActorSpawnParameters());

            PBPlayerState->CurrentAmmo -= 1;
            UE_LOG(LogTemp, Display, TEXT("Current Ammo: %f"), PBPlayerState->CurrentAmmo);

    }

}

