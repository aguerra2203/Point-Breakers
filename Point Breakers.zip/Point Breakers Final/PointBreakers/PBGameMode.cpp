// Fill out your copyright notice in the Description page of Project Settings.


#include "PointBreakers/PBGameMode.h"
#include "PointBreakers/PBPlayerController.h"
#include "PointBreakers/PBCharacter.h"
#include "PointBreakers/PBGameState.h"
#include "PointBreakers/PBGameInstance.h"
#include "PointBreakers/PBPlayerState.h"
#include "PointBreakers/Grenade.h"
#include "Kismet/GameplayStatics.h"

#pragma region Unreal Functions
APBGameMode::APBGameMode()
{
	// Set this Actor to call Tick() every frame. Tick() will never be called without it!
	PrimaryActorTick.bCanEverTick = true;

	// Initialize some of the defaults (blueprinting this will override it)
	// Notice the use of StaticClass to get the UClass class type properly
	DefaultPawnClass = APBCharacter::StaticClass();
	PlayerControllerClass = APBPlayerController::StaticClass();
	GameStateClass = APBGameState::StaticClass();
	PlayerStateClass = APBPlayerState::StaticClass();
}

void APBGameMode::BeginPlay()
{
	Super::BeginPlay();

	// Cache a reference to our GameState
	PBGameState = GetGameState<APBGameState>();

	// Set the initial point amount
	UPBGameInstance* PBGameInstance = GetWorld()->GetGameInstance<UPBGameInstance>();

	if (PBGameInstance->PersistentPoints == -1) {
		PBGameInstance->PersistentPoints = InitialPointCount;
	}

	PBGameState->CurrentPoints = PBGameInstance->PersistentPoints;

	// Initialize game timer
	PBGameState->TimeRemaining = GameTime;


	// Set the ammo
	APBPlayerController* PBPlayerController = Cast<APBPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
	PBPlayerState = PBPlayerController->GetPlayerState<APBPlayerState>();
	if (PBGameInstance->PersistentAmmo == -1)
	{
		// Initialize the amount of ammo
		PBGameInstance->PersistentAmmo = InitialAmmoCount;
	}

	// Update GameState to reflect current ammo
	PBPlayerState->CurrentAmmo = PBGameInstance->PersistentAmmo;
	

}

void APBGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	UPBGameInstance* PBGameInstance = GetWorld()->GetGameInstance<UPBGameInstance>();
	// While there's time left
	if (PBGameState->TimeRemaining > 0.f)
	{
		// Decrement timer and check for game completion
		PBGameState->TimeRemaining -= DeltaTime;


		// If time has run out
		if (PBGameState->TimeRemaining <= 0.f)
		{
			// End the game
			PBGameState->TimeRemaining = 0.f;
			PBGameInstance->PersistentPoints = -1;
			PBGameInstance->PersistentAmmo = -1;
			PBGameState->Lose = true;
			UE_LOG(LogTemp, Display, TEXT("Ran out of time, Game Over!"));

		}

		if (PBGameState->CurrentPoints >= 500)
		{
			// End the game
			PBGameState->TimeRemaining = 0.f;
			PBGameInstance->PersistentPoints = -1;
			PBGameInstance->PersistentAmmo = -1;
			PBGameState->Win = true;
			UE_LOG(LogTemp, Display, TEXT("You've reached 500 points, You Win!"));

		}

	}
}
#pragma endregion
