// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "PointBreakers/PBGameState.h"
#include "PointBreakers/PBPlayerState.h"
#include "PBGameMode.generated.h"

/**
 * 
 */
UCLASS()
class APBGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	APBGameMode();

#pragma region Unreal Functions
protected:
	virtual void BeginPlay() override;

public:
	virtual void Tick(float DeltaTime) override;
#pragma endregion

public:
	UPROPERTY(EditAnywhere, Category = "Game Rules")
	float GameTime = 180.f;

	UPROPERTY(EditAnywhere, Category = "Game Rules")
	int32 InitialPointCount = 0;

	UPROPERTY(EditAnywhere, Category = "Game Rules")
	int32 InitialAmmoCount = 10;

	APBGameState* PBGameState;
	APBPlayerState* PBPlayerState;
};
