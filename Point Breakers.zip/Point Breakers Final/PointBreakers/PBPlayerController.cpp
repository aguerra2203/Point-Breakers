// Fill out your copyright notice in the Description page of Project Settings.


#include "PointBreakers/PBPlayerController.h"
#include "Components/InputComponent.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Blueprint/UserWidget.h"
#include "InputActionValue.h"
#include "PBPlayerController.h"

void APBPlayerController::BeginPlay()
{
    // Unless you have a good reason not to, you should always call
    // the Super version of any functions Unreal gives you
    Super::BeginPlay();

    // Get the Enhanced Input Local Player Subsystem from the PlayerController (and the LocalPlayer)
    if (UEnhancedInputLocalPlayerSubsystem* EILPSubsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer()))
    {
        // Use the subsystem to add the mapping context
        EILPSubsystem->AddMappingContext(ControllerContext, 100);
    }

    InMainMenu = true;

    if (MenuUIClass) {
        MenuUIWidget = CreateWidget(this, MenuUIClass);

    }

    if (HUDClass) {
        HUDWidget = CreateWidget(this, HUDClass);
    }

    if (EndUIClass) {
        EndUIWidget = CreateWidget(this, EndUIClass);
    }

    if (PauseUIClass) {
        PauseUIWidget = CreateWidget(this, PauseUIClass);
    }


  



}

void APBPlayerController::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);



}

void APBPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();

    // Take our PlayerInputComponent (InputComponent) and cast it to a UEnhancedInputComponent
    // This lets us tap into the features of the new Enhanced Input system
    // CastChecked is like Cast, but will crash on failure
    if (UEnhancedInputComponent* EnhancedInputComponent = CastChecked<UEnhancedInputComponent>(InputComponent))
    {
        // Bind Input Actions to Callback Functions
        EnhancedInputComponent->BindAction(PauseAction, ETriggerEvent::Triggered, this, &APBPlayerController::PauseCallback);
        EnhancedInputComponent->BindAction(InteractAction, ETriggerEvent::Triggered, this, &APBPlayerController::InteractCallback);
    }
}

void APBPlayerController::PauseCallback(const FInputActionValue& Value)
{
    UE_LOG(LogTemp, Display, TEXT("Pause Input"));

    // Resume the game if paused, and pause otherwise
    if (IsPaused()) { 
        SetPause(false);
        SetInputMode(FInputModeGameOnly());
    }
    else { 
        Pause(); 
        SetInputMode(FInputModeUIOnly());
        PauseUIWidget->AddToViewport();
    }
}

void APBPlayerController::InteractCallback(const FInputActionValue& Value)
{
    UE_LOG(LogTemp, Display, TEXT("Interact Input"));

}
