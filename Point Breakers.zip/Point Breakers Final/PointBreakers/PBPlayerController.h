// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "Blueprint/UserWidget.h"
#include "PBPlayerController.generated.h"

/**
 *
 */

class UInputMappingContext;
class UInputAction;
struct FInputActionValue;


UCLASS()
class APBPlayerController : public APlayerController
{
	GENERATED_BODY()

#pragma region Unreal Functions
protected:
	virtual void BeginPlay() override;

	virtual void Tick(float DeltaTime) override;

	virtual void SetupInputComponent() override;
#pragma endregion


private:
#pragma region Inputs

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputMappingContext> ControllerContext;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> PauseAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> InteractAction;

#pragma endregion

#pragma region UI

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	TSubclassOf<UUserWidget> HUDClass;

	UPROPERTY()
	TObjectPtr<UUserWidget> HUDWidget;

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	TSubclassOf<UUserWidget> EndUIClass;

	UPROPERTY()
	TObjectPtr<UUserWidget> EndUIWidget;

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	TSubclassOf<UUserWidget> PauseUIClass;

	UPROPERTY()
	TObjectPtr<UUserWidget> PauseUIWidget;

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	TSubclassOf<UUserWidget> MenuUIClass;

	UPROPERTY()
	TObjectPtr<UUserWidget> MenuUIWidget;


#pragma endregion

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Main Menu");
	bool InMainMenu;

private:
#pragma region Input Callbacks

	// Function used as a callback from an Input Action event
	void PauseCallback(const FInputActionValue& Value);

	// Function used as a callback from an Input Action event
	void InteractCallback(const FInputActionValue& Value);


#pragma endregion
};
