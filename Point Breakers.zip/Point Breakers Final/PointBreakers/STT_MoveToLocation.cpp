// Fill out your copyright notice in the Description page of Project Settings.


#include "PointBreakers/STT_MoveToLocation.h"
#include "AIController.h"

EStateTreeRunStatus USTT_MoveToLocation::Tick(FStateTreeExecutionContext& Context, const float DeltaTime)
{
	// If we've arrived at the target location (within 100cm)
	if (FVector::Distance(ThisActor->GetActorLocation(), TargetLocation) < 100.f)
	{
		// Finish Task with a Success!
		return EStateTreeRunStatus::Succeeded;
	}
	else // We have not yet arrived
	{
		// Cast ThisActor to a Pawn so we can get its controller
		if (APawn* ActorAsPawn = Cast<APawn>(ThisActor))
		{
			if (AAIController* AIController = Cast<AAIController>(ActorAsPawn->GetController()))
			{
				// Move our AI to the TargetLocation
				AIController->MoveToLocation(TargetLocation);

				// Still in progress
				return EStateTreeRunStatus::Running;
			}
		}
	}

	// We should never reach this point
	return EStateTreeRunStatus::Failed;
}
